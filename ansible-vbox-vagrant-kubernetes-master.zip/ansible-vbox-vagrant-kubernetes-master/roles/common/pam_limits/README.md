# PAM_LIMITS
Sets the pam limits of the host.

 